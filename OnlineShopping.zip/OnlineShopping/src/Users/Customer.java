
package Users;

/**
 *
 * @author jmayoral2017
 */
public class Customer extends User{
    
    public Customer(String username, String password, String type) {
        super(username, password, type);
    }
    
}
