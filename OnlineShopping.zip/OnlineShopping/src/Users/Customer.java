package Users;
/**
 *
 * extends the Customer class
 */
public class Customer extends User{
    
    public Customer(String username, String password, String type) {
        super(username, password, type);
    }
    
}
