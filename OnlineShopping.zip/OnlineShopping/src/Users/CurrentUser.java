/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Users;

/**
 *
 * @author SupaManlyMan
 */
public class CurrentUser extends User{
    
    public CurrentUser(String username, String password, String type) {
        super(username, password, type);
    }
    
}
