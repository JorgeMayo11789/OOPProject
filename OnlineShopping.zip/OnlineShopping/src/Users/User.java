package Users;

public class User {
	private String username;
	private String password;
	private String type;
	public User(String username, String password, String type)
	{
		this.username = username;
		this.password = password;
		this.type = type;
	}
	public String print()
	{
		return (username+" "+password+" "+type);
	}
	public String user()
	{
		return username;
	}
	public String pass()
	{
		return password;
	}
	public String type()
	{
		return type;
	}

}
