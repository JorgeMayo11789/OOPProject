package Users;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

public class UserList {
	ArrayList<users> UserList = new ArrayList<users>();
	public UserList()
	{
	}
	public void addUser(users u1)
	{
		UserList.add(u1);
	}
	public void addnewUser(users u1) throws IOException
	{
		int size = UserList.size();
		addUser(u1);
		FileWriter fw = new FileWriter("src/users.txt");
		PrintWriter pw = new PrintWriter(fw);
		System.out.println(UserList.get(size).user()+" "+UserList.get(size).pass()+" "+UserList.get(size).type());
		for(int i = 0;i<size+1;i++)
		{
			pw.println(UserList.get(i).user()+" "+UserList.get(i).pass()+" "+UserList.get(i).type());
		}
		pw.close();
		fw.close();
		
	}
	public void showUsers()
	{
		int size = UserList.size();
		for(int i = 0; i<size;i++)
		{
			System.out.println(UserList.get(i).print());
		}
	}
	public int getSize() {
		// TODO Auto-generated method stub
		return UserList.size();
	}
	public String getUser(int i)
	{
		return UserList.get(i).user();
		
	}
	public String getPass(int i)
	{
		return UserList.get(i).pass();
	}
	public Object getType(int i) {
		// TODO Auto-generated method stub
		return UserList.get(i).type();
	}
}
