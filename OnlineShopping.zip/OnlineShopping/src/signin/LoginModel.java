/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package signin;

import Users.Customer;
import Users.Seller;
import Users.User;
import Users.UserList;
public class LoginModel {
    UserList l1 = null;
    User u = null;
    public LoginModel(UserList l1)
    {
        this.l1 = l1;
    }
    public int checkCredentials(String user, String pass)
    {
        for(int i = 0;i<l1.getSize();i++)
        {
            if(user.equals(l1.getUser(i)))
            {
                if(pass.equals(l1.getPass(i)))
                {
                    if(l1.getType(i).equals("Customer"))
                    {
                        u = new Customer(l1.getUser(i),l1.getPass(i),"Customer");
                  
                        return 1;
                    }
                    else
                    {
                        u = new Seller(l1.getUser(i),l1.getPass(i),"Seller");
                        return 2;
                    }
                    
                }
            }
        }
        return 0;
    }
    public User getCurrentUser()
    {
        return u;
    }
}
