package signin;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import registerNewUser.RegisterController;
import registerNewUser.RegisterView;
import Shoppingsystem.ShoppingSystemMain;
import Users.UserList;

public class SigninController {
	private String user;
	private String pass;
	String type = null;
	SignInPageView view;
	private int finished;

	public SigninController(final UserList l1, final SignInPageView v) {
		v.btn1.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				view = v;
				user = v.tf1.getText();
				pass = v.tf2.getText();
				int size = l1.getSize();
				for(int i =0;i<size;i++)
				{
					if(user.equals(l1.getUser(i)))
					{
						System.out.println("Correct User");
						if(pass.equals(l1.getPass(i)))
						{
							System.out.println("Correct Pass");
							if(l1.getType(i).equals("Customer"))
							{
		
								System.out.println("correct");
								closeview();
								type = "Customer";
								ShoppingSystemMain.productlist();
							}
							else if(l1.getType(i).equals("Seller"))
							{
								System.out.println("correct2");
								closeview();
								type = "Seller";
							}
						}
					}
				}
				
			}
		});
		v.btn2.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				v.closeframe();
				System.out.println("Frame closed");
				RegisterController rc = new RegisterController(l1, new RegisterView());
				System.out.println("frame opened");
			}
		});
		
		// TODO Auto-generated constructor stub
	}
	public String getEnteredUser()
	{
		return user;
		
	}
	public String getEnteredPass()
	{
		return pass;
	}
	public void closeview()
	{
		view.closeframe();
	}
	public String getType()
	{
		return type;
	}
	public int finished() {
		// TODO Auto-generated method stub
		return finished;
	}

}
