package Productstuff;

public class Products {
	private String name;
	private double cost;
	private int ID;
	private String Seller;
	public Products(String name, int ID, double cost, String seller)
	{
		
	}
	public void setName(String name)
	{
		
	}
	public void setCost(int cost)
	{
		
	}
	public void setID(int ID)
	{
		
	}
}
