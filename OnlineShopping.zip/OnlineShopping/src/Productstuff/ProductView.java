/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Productstuff;

import java.awt.BorderLayout;
import java.awt.Container;
import java.io.FileNotFoundException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
/**
 *
 * @author jmayoral2017
 */
public class ProductView extends JFrame{
     JLabel l1, l2, l3;
JButton btnCart, btnLogout;
    public ProductView() throws FileNotFoundException
    {
       l1 = new JLabel("Product Information");
    	 l2 = new JLabel("Product List");
    	 btnCart = new JButton("Add to Cart");
    	 btnLogout = new JButton("LogOut");
    	 l1.setBounds(10,10,100,100);
    	this.setLayout(new BorderLayout());
        //headers for the table
        //actual data for the table in a 2d array
        ////////
        Container c = getContentPane(); 
        c.setLayout(null); 
        c.add(l1);
        c.add(btnLogout);
        c.add(btnCart);
        l1.setBounds(10, 10, 100, 50);
        btnLogout.setBounds(200, 50, 100, 50);
        btnCart.setBounds(130, 210, 150, 50);
        this.setLayout(null);
        this.setTitle("Table Example");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //this.pack();
        this.setSize(300,300);
        this.setLocationRelativeTo(null); 
        this.setVisible(true);
        
    }
}
