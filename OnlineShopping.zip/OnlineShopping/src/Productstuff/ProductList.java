package Productstuff;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import Users.users;

public class ProductList {
	ArrayList<Products> products = new ArrayList<Products>();
	public ProductList() throws FileNotFoundException
	{
		File file = new File("src/products.txt");
		 BufferedReader br = new BufferedReader(new FileReader(file)); 
		  String st;
		  String[] split;
		  try {
				while ((st = br.readLine()) != null)
				{
					split = st.split("\\s+");
				    Products p1 = new Products(split[0], Integer.parseInt(split[1]),Double.parseDouble(split[2]), split[3]);
				    products.add(p1);
				}
				
					
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		  
	}
	
}
