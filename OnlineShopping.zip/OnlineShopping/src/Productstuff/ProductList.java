package Productstuff;
import java.io.FileNotFoundException;
import java.util.ArrayList;
public class ProductList {
	ArrayList<Products> products = new ArrayList<Products>();
	public ProductList() throws FileNotFoundException
	{
        }
	public void addProduct(Products p)
        {
            products.add(p);
        }

    void printlist() {
        for(int i = 0;i<products.size();i++)
        {
            System.out.println(products.get(i).getID());
            System.out.println(products.get(i).getName());
            System.out.println(products.get(i).getCost());
            System.out.println(products.get(i).getquantity());
            System.out.println(products.get(i).getSeller());
        }
    }

    int size() {
        return products.size();
    }
}
