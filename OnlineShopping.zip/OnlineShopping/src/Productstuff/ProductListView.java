package Productstuff;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Point;

import javax.swing.*;

public class ProductListView extends JFrame
{
	JLabel l1, l2, l3;
	JButton btnShop, btnLogout;
    public ProductListView()
    {
    	 l1 = new JLabel("Welcome user!");
    	 l2 = new JLabel("Product List");
    	 btnShop = new JButton("Cart");
    	 btnLogout = new JButton("LogOut");
    	 l1.setBounds(10,10,100,100);
    	this.setLayout(new BorderLayout());
        //headers for the table
        String[] columns = new String[] {
            "Id", "Name", "Cost", "Seller","Quantity"
        };
         
        //actual data for the table in a 2d array
        Object[][] data = new Object[][] {
            {1, "Milk", 40.0, "Bob",5 },
            {2, "Juice", 70.0, "Bob",5 },
            {3, "Iphone", 60.0, "Bob", 5},
        };
        //create table with data
        JTable table = new JTable(data, columns);
        Container c = getContentPane(); 
        c.setLayout(null); 
        JScrollPane scroller = new JScrollPane(table); 
        c.add(scroller); 
        scroller.setBounds(160, 100, 700, 300);
        c.add(l1);
        c.add(btnLogout);
        c.add(btnShop);
        l1.setBounds(450, 50, 100, 50);
        btnLogout.setBounds(880, 20, 100, 50);
        btnShop.setBounds(780, 20, 70, 50);
        this.setLayout(null);

        //tablePanel.setLayout(new BorderLayout());


        //add the table to the frame
        //this.add(new JScrollPane(table));
         
        this.setTitle("Table Example");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //this.pack();
        this.setSize(1000,500);
        this.setLocationRelativeTo(null); 
        this.setVisible(true);
    }
}
