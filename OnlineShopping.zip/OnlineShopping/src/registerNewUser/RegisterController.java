package registerNewUser;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import Users.UserList;
import Users.User;
	public class RegisterController {
		private String user;
		private String pass;
		String type = null;
		RegisterView view = null;
		private int success = 0;
		private int taken = 0;
		public RegisterController(final UserList l1, final RegisterView v) {
			v.btn2.addActionListener(new ActionListener(){

				public void actionPerformed(ActionEvent arg0) {
					// TODO Auto-generated method stub
					view = v;
					user = v.tf1.getText();
					pass = v.tf2.getText();
					int size = l1.getSize();
					for(int i =0;i<size;i++)
					{
						if(user.equals(l1.getUser(i)))
						{
							System.out.println("Username aready taken");
							taken = 1;
						}
					}
					if(taken == 0)
					{
                                                
						User newuser = new User(user, pass,v.cb.getSelectedItem().toString());
                                                success =1;
						try {
							l1.addnewUser(newuser);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							
						}
						v.closeframe();
					}
				}
			});
			v.btn1.addActionListener(new ActionListener(){

				public void actionPerformed(ActionEvent arg0) {
					// TODO Auto-generated method stub
					v.closeframe();
					System.out.println("click");
                                        success = -1;
				}
				
			});
			
			// TODO Auto-generated constructor stub
		}
		public String getEnteredUser()
		{
			return user;
		}
		public String getEnteredPass()
		{
			return pass;
		}
		public void closeview()
		{
                    view.closeframe();
		}
		public String getType()
		{
			return type;
		}
                public int confirmRegsitration()
                {
                    return success;
                }
	}