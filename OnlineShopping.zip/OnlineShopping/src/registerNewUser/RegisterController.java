	package registerNewUser;

	import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import registerNewUser.RegisterController;
import registerNewUser.RegisterView;
import Shoppingsystem.ShoppingSystemMain;
import Users.UserList;
import Users.users;
	public class RegisterController {

		private String user;
		private String pass;
		String type = null;
		RegisterView view;
		private int success = 0;
		private int taken = 0;

		public RegisterController(final UserList l1, final RegisterView v) {
			v.btn2.addActionListener(new ActionListener(){

				public void actionPerformed(ActionEvent arg0) {
					// TODO Auto-generated method stub
					view = v;
					user = v.tf1.getText();
					pass = v.tf2.getText();
					int size = l1.getSize();
					for(int i =0;i<size;i++)
					{
						if(user.equals(l1.getUser(i)))
						{
							System.out.println("Username aready taken");
							taken = 1;
						}
					}
					if(taken == 0)
					{
						System.out.println("New user created!");
						users newuser = new users(user, pass, "Customer");
						try {
							l1.addnewUser(newuser);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							
						}
						v.closeframe();
						ShoppingSystemMain.productlist();
					}
				}
			});
			v.btn1.addActionListener(new ActionListener(){

				public void actionPerformed(ActionEvent arg0) {
					// TODO Auto-generated method stub
					v.closeframe();
					System.out.println("click");
					ShoppingSystemMain.signin();
				}
				
			});
			
			// TODO Auto-generated constructor stub
		}
		public String getEnteredUser()
		{
			return user;
		}
		public String getEnteredPass()
		{
			return pass;
		}
		public void closeview()
		{
				view.closeframe();
		}
		public String getType()
		{
			return type;
		}
	}