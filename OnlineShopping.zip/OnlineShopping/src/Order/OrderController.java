package Order;


public class OrderController {
    private OrderView ov;
    private OrderModel om;
    public OrderController(OrderModel om, OrderView ov)
    {
        this.ov = ov;
        this.om = om;
        setTotalCost();
    }
    public void setTotalCost()
    {
        ov.updateView(om.getTotalCost());
    }
    
}
