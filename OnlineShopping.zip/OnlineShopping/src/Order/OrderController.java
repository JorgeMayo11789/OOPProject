package Order;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class OrderController {
    private OrderView ov;
    private OrderModel om;
    public OrderController(OrderModel om, OrderView ov)
    {
        this.ov = ov;
        this.om = om;
        setTotalCost();
        confirmControl();
    }
    public void setTotalCost()
    {
        ov.updateView(om.getTotalCost());
    }
    public void confirmControl()
    {
        ov.btnConfirm.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                System.out.println("Order confirmed");
                try {
                    om.getCart().updateQuantities();
                    om.updateProductList();
                    om.updateRevenue();
                } catch (IOException ex) {
                    Logger.getLogger(OrderController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        
    });
    }
    
}
