/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Order;

import ShoppingCart.CartList;

/**
 *
 * @author jmayoral2017
 */
public class OrderModel {
    private CartList cl;
    public OrderModel(CartList cl){
        this.cl = cl;
    }
    public String getTotalCost()
    {
        return Double.toString(cl.getTotalCost());
    }
    
}
