package Order;
import ShoppingCart.CartList;
import ShoppingCart.ShoppingCartModel;
public class OrderModel {
    private CartList cl;
    ShoppingCartModel scm;
    public OrderModel(CartList cl,ShoppingCartModel scm){
        this.cl = cl;
        this.scm = scm;
    }
    public String getTotalCost()
    {
        return Double.toString(cl.getTotalCost());
    }
    public CartList getCart()
    {
        return cl;
    }
    public void updateProductList()
    {
        scm.ProductListView();
    }

    void updateRevenue()
    {
        
        
    }
}
