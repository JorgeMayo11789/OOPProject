/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Order;

import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author jmayoral2017
 */
public class OrderView extends JFrame{
    JLabel ltotal, lcc;
    Container c;
    JTextField textcreditcard;
    public OrderView()
    {
        c = getContentPane();
        ltotal = new JLabel("swag");
        lcc = new JLabel("Please enter credit card info");
        textcreditcard = new JTextField();
        c.add(ltotal);
        c.add(textcreditcard);
        c.add(lcc);
        ltotal.setBounds(10,100,100,50);
        lcc.setBounds(10,150,300,30);
        textcreditcard.setBounds(10,200,300,30);
        this.setLayout(null);
        this.setTitle("Table Example");
        this.setSize(400,400);
        this.setLocationRelativeTo(null); 
        this.setVisible(true);    
    }
    public void updateView(String s)
    {
        ltotal.setText(s);
    }
    
}
