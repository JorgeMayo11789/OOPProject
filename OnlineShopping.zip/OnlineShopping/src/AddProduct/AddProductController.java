/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AddProduct;

import ProductList.ProductList;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author jmayoral2017
 */
public class AddProductController {
    private ProductList pl;

    public AddProductController(AddProductView apv, AddProductModel apm, ProductList pl) {
        this.pl = pl;
        apv.btnFinish.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                if(apm.checkTypes(apv.textname.getText(),apv.textprice.getText(),apv.textstock.getText()).equals("yes"))
                {
                     String s1 = apm.validateInfo(apv.getName(),apv.getPrice(),apv.getQuantity(),pl);
                }
                else
                {
                    System.out.println("type error");
                }
               
            }
            
        });
        
        
    }
    
}
