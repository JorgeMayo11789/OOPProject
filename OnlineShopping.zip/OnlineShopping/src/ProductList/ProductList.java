package ProductList;
import java.util.ArrayList;
public class ProductList {
	public ArrayList<Products> products = new ArrayList<Products>();
	public ProductList()
	{
        }
	public void addProduct(Products p)
        {
            products.add(p);
        }
        public Products getProductFromID(int ID)
        {
            for(int i = 0;i<products.size();i++)
            {
                if(products.get(i).getID() == ID)
                {
                    return products.get(i);
                }
            }
            return null;
        }
   public  void printlist() {
        for(int i = 0;i<products.size();i++)
        {
            System.out.println(products.get(i).getID());
            System.out.println(products.get(i).getName());
            System.out.println(products.get(i).getCost());
            System.out.println(products.get(i).getquantity());
            System.out.println(products.get(i).getSeller());
        }
    }
    public int size() {
        return products.size();
    }
}
