/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProductList;

import ProductDetail.ProductDetailModel;
import ProductDetail.ProductDetailController;
import ProductDetail.ProductDetailView;
import ShoppingCart.CartList;
import ShoppingCart.ShoppingCartController;
import ShoppingCart.ShoppingCartModel;
import ShoppingCart.ShoppingCartView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;

/**
 *
 * @author jmayoral2017
 */

public class ProductListController {
    private ProductListView v;
    private ProductListModel m;
    private ProductList pl = null;
    private CartList cl;
    private boolean closed = false;
    public ProductListController(ProductListView v, ProductListModel m, CartList cl)
    {
        this.v = v;
        this.m = m;
        this.cl = cl;
    }
    public void populateTable() throws FileNotFoundException
    {
       v.setTable(m.getTableData(),m.getProductList());
    }
    public void tableControl()
    {
        v.getTable().addMouseListener(new java.awt.event.MouseAdapter(){
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            int productID = Integer.parseInt(v.getTable().getValueAt(v.getTable().getSelectedRow(),0).toString());
            if(Integer.parseInt(v.getTable().getValueAt(v.getTable().getSelectedRow(),3).toString()) != 0)
            {
                pl = m.getProductList();
                cl.addList(pl);
                ProductDetailModel pdm = new ProductDetailModel(pl.getProductFromID(productID));
                ProductDetailView pv = new ProductDetailView();
                ProductDetailController pdc = new ProductDetailController(pdm,pv,cl);
                pdc.CartButton();
            }
           
            
        }
    });
    }
    public void cartControl()
    {
        v.getCart().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ShoppingCartView scv = new ShoppingCartView();
                ShoppingCartModel scm = new ShoppingCartModel(v,cl);
                ShoppingCartController scc = new ShoppingCartController(scv,scm,pl);
                
               System.out.println("Cart open");
            }
            
        });
    }

    public boolean logoutControl() {
        v.getLogout().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                v.setVisible(false);
                v.dispose();
                closed = true;
            }  
        });
        return closed;
}

    public void updateTable() {
        v.updateTable();
    }
}
