/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProductList;

import ProductDetail.ProductDetailModel;
import ProductDetail.ProductDetailController;
import ProductDetail.ProductDetailView;
import ShoppingCart.CartList;
import ShoppingCart.ShoppingCartView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author jmayoral2017
 */

public class ProductListController {
    private ProductListView v;
    private ProductListModel m;
    private ProductList pl = null;
    private CartList cl;
    public ProductListController(ProductListView v, ProductListModel m, CartList cl)
    {
        this.v = v;
        this.m = m;
        this.cl = cl;
    }
    public void tableControl()
    {
        v.getTable().addMouseListener(new java.awt.event.MouseAdapter(){
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            System.out.println(v.getTable().getValueAt(v.getTable().getSelectedRow(), 0).toString());
            int productID = Integer.parseInt(v.getTable().getValueAt(v.getTable().getSelectedRow(),0).toString());
            pl = v.getProductList();
            ProductDetailModel pdm = new ProductDetailModel();
            ProductDetailView pv = new ProductDetailView(pl.getProductFromID(productID));
            ProductDetailController pdc = new ProductDetailController(pdm,pv,cl);
            pdc.CartButton();
            
        }
    });
    }
    public void cartControl()
    {
        v.getCart().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ShoppingCartView scv = new ShoppingCartView(cl);
               System.out.println("Cart open");
            }
            
        });
    }
    public ProductList getList()
    {
        pl = v.getProductList();
        return pl;
    }
    
}
