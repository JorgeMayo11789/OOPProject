package ProductList;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author jmayoral2017
 */
public class ProductListModel {
    ProductList pl = new ProductList();
    public Object[][] getTableData() throws FileNotFoundException
    {
        //actual data for the table in a 2d array
        ////////
        
        System.out.println("List of Users: Username, password, User type(Customer/Seller)");
		 File file = new File("src/products.txt");
		 BufferedReader br = new BufferedReader(new FileReader(file)); 
		  String st;
		  String[] split;
		  try {
			while ((st = br.readLine()) != null)
			{
                            split = st.split("\\s+");
			    Product p1 = new Product(Integer.parseInt(split[0]),split[1],Double.parseDouble(split[2]),Integer.parseInt(split[3]),split[4]);
                            pl.addProduct(p1);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
                }
         Object[][] data = new Object[pl.size()][5];
         for(int i = 0;i<pl.size();i++)
         {
                data[i][0] = pl.products.get(i).getID();
                data[i][1] = pl.products.get(i).getName();
                data[i][2] = pl.products.get(i).getCost();
                data[i][3] = pl.products.get(i).getquantity();
                data[i][4] = pl.products.get(i).getSeller();
         }
         return data;
    }
   ProductList getProductList() {
        return pl;
    }
}
