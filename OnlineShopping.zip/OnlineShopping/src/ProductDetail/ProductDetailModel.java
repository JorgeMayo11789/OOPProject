
package ProductDetail;

import ProductList.Product;

public class ProductDetailModel {
    Product p;
    public ProductDetailModel(Product p) {
        this.p = p;
    }
    public String getName()
    {
        return p.getName();
    }
    public int getID()
    {
        return p.getID();
    }
    public double getCost()
    {
        return p.getCost();
    }
    public int getQuantity()
    {
        return p.getquantity();
    }
    public String getSeller()
    {
        return p.getSeller();
    }
}
