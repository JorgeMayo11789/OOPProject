
package ProductDetail;

import ShoppingCart.CartList;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class ProductDetailController {
    private ProductDetailModel pdm;
    private ProductDetailView pv;
    private CartList cl;

    public ProductDetailController(ProductDetailModel pdm, ProductDetailView pv, CartList cl) {
        this.pdm = pdm;
        this.pv = pv;
        this.cl = cl;
        
    }
    public void CartButton()
    {
        pv.btnAddToCart.addActionListener(new ActionListener(){
           @Override
           public void actionPerformed(ActionEvent e) {
               System.out.print("Adding "+pv.p.getName());
               cl.addToCart(pv.p.getProduct());
           }
        });
    }
}
