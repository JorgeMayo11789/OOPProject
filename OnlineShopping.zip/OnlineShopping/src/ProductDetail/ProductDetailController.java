
package ProductDetail;

import ShoppingCart.CartList;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;


public class ProductDetailController {
    private ProductDetailModel pdm;
    private ProductDetailView pv;
    private CartList cl;
    private int quantity = 1;

    public ProductDetailController(ProductDetailModel pdm, ProductDetailView pv, CartList cl) {
        this.pdm = pdm;
        this.pv = pv;
        this.cl = cl;
        SliderControl();
        if(cl.getProductQuantity(pv.p) == pv.p.getquantity())
        {
            pv.btnAddToCart.setEnabled(false);
        }
        
    }
    public void CartButton()
    {
        pv.btnAddToCart.addActionListener(new ActionListener(){
           @Override
           public void actionPerformed(ActionEvent e) {
               System.out.print("Adding "+pv.p.getName());
               for(int i = 0;i<quantity;i++)
               {
                    cl.addToCart(pv.p.getProduct());
               }
                pv.updateQuantity();
                if (quantity == pv.p.getquantity())
                {
                    pv.btnAddToCart.setEnabled(false);
                }
              
           }
        });
    }
    public void SliderControl()
    {
        pv.slider.addChangeListener(new ChangeListener(){
            public void stateChanged(ChangeEvent event)
            {
                quantity = pv.slider.getValue();
                pv.updateSliderLabel();
            }
        });
    }
}
