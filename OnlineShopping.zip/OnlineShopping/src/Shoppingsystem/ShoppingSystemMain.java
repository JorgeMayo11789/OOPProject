package Shoppingsystem;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import Productstuff.ProductListView;
import Users.UserList;
import Users.users;
import java.io.FileNotFoundException;
import signin.*;

public class ShoppingSystemMain {
	static int success = 0;
	static SigninController s = null;
	static UserList l1 = new UserList();
	public static void main(String[] args) throws IOException 
	{
		System.out.println("List of Users: Username, password, User type(Customer/Seller)");
		 File file = new File("src/users.txt");
		 BufferedReader br = new BufferedReader(new FileReader(file)); 
		  String st;
		  String[] split;
		  try {
			while ((st = br.readLine()) != null)
			{
				split = st.split("\\s+");
			    users u1 = new users(split[0], split[1], split[2]);
			    l1.addUser(u1);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		  br.close();
		  l1.showUsers();
		  System.out.println();
		  signin();
		  //ProductListView pv = new ProductListView();
	}
	public static void signin()
	{
		//displays signin page
		s = new SigninController(l1,new SignInPageView());
			
	}
	//displays product list
	public static void productlist() throws FileNotFoundException{
		ProductListView pv = new ProductListView();
		// TODO Auto-generated method stub
	}
}
