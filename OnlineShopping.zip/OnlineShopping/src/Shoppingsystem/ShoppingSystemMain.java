package Shoppingsystem;
import Inventory.InventoryController;
import Inventory.InventoryModel;
import Inventory.InventoryView;
import ProductList.ProductListController;
import ProductList.ProductListModel;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import ProductList.ProductListView;
import ShoppingCart.CartList;
import Users.CurrentUser;
import Users.UserList;
import Users.User;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import registerNewUser.RegisterController;
import registerNewUser.RegisterView;
import signin.*;

public class ShoppingSystemMain {
	private int success = 0;
	static UserList l1 = new UserList();
        private CartList cartlist = new CartList();
        private int loop = 0;
        private CurrentUser cu = null;
        public ShoppingSystemMain(UserList l1) throws FileNotFoundException, IOException
        {
            //gets the list of user from the file users.txt
            populateUserList();
            //starts login frame
            Login();
        }
        public void populateUserList() throws IOException
        {
            //gets users from file
            System.out.println("List of Users: Username, password, User type(Customer/Seller)");
            System.out.println();
            File file = new File("src/users.txt");
            BufferedReader br = new BufferedReader(new FileReader(file)); 
            String st;
            String[] split;
            try {
			while ((st = br.readLine()) != null)
			{
                            split = st.split("\\s+");
			    User u1 = new User(split[0], split[1], split[2]);
                            System.out.println(split[0]+" "+split[1]);
			    l1.addUser(u1);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		  br.close();
        }
        public void Login() throws FileNotFoundException
        {
            //checks to make sure user is logged in before proceeding
            while (loop == 0)
            {
                //loginpage
                LoginModel m = new LoginModel(l1);
                LoginView v = new LoginView();
                LoginController c = new LoginController(m,v,l1);
                c.Register();
           
                while(c.Login() == 0)
                {
                    try {
                        //waits for input
                    Thread.sleep(1000);
                        } catch (InterruptedException ex) {
                    Logger.getLogger(ShoppingSystemMain.class.getName()).log(Level.SEVERE, null, ex);
                        }
                }
            switch(c.Login())
            {
                case 0:
                   
                    break;
                //customer
                case 1:
                     cu = c.getCurrentUser();
                     loop = 1;
                     ProductList();
                    break;
                //seller
                case 2:
                     cu = c.getCurrentUser();
                     loop = 1;
                     Inventory();
                    break;
                 //register new user
                case 3:
                    Register();
                    break;
                        
            }
            }
        }
        public void ProductList() throws FileNotFoundException
        {
            //displays product list for customer
            ProductListModel pm = new ProductListModel();
            ProductListView pv = new ProductListView();
            ProductListController pc = new ProductListController(pv,pm,cartlist);
            pc.tableControl();
            pc.cartControl();
        }
         public void Inventory() throws FileNotFoundException 
        {
            //displays inventory for seller
            InventoryModel im = new InventoryModel();
            InventoryView iv = new InventoryView(cu);
            InventoryController ic = new InventoryController(iv,im);
            ic.addNewProductButton();
        }
         //registers new user
         public void Register() throws FileNotFoundException
         {
                 RegisterView rv = new RegisterView();
                RegisterController rc = new RegisterController(l1,rv);
                while(rc.confirmRegsitration() == 0)
                {
                     try {
                    Thread.sleep(500);
                    } catch (InterruptedException ex) {
                    Logger.getLogger(ShoppingSystemMain.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                System.out.println(rc.confirmRegsitration());
                if(rc.confirmRegsitration() == 1)
                {
                    System.out.println("New user created");
                    loop = 1;
                    ProductList();
                }
                else if(rc.confirmRegsitration() == -1)
                {
                    System.out.println("Cancel button pressed");
                }
         }
	public static void main(String[] args) throws IOException
	{
            System.out.println("Hello");
		  ShoppingSystemMain s = new ShoppingSystemMain(l1);
		  System.out.println();
        }
}
