/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ShoppingCart;

import EditProduct.EditProductController;
import EditProduct.EditProductModel;
import EditProduct.EditProductView;
import ProductList.ProductList;
import ProductList.Product;

/**
 *
 * @author jmayoral2017
 */
public class ShoppingCartController {
private ShoppingCartView scv;
private ShoppingCartModel scm;
private ProductList pl;
private CartList cl;
    public ShoppingCartController(ShoppingCartView scv, ShoppingCartModel scm,CartList cl,ProductList pl) {
        this.scm = scm;
        this.scv = scv;
        this.pl = pl;
        this.cl = cl;
        removeControl();
        
    }
    public void removeControl()
    {
        scv.getTable().addMouseListener(new java.awt.event.MouseAdapter(){
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            int productID = Integer.parseInt(scv.getTable().getValueAt(scv.getTable().getSelectedRow(),0).toString());
            System.out.println(productID);
            Product p = pl.getProductFromID(productID);
            cl.removeFromCart(p);
            scv.updateTable();
            

           
            
             
           
        }
        }
        );
    }
}
            
             