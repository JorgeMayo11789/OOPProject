/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ShoppingCart;
import ProductList.ProductList;
import ProductList.Product;
import Order.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author jmayoral2017
 */
public class ShoppingCartController {
private ShoppingCartView scv;
private ShoppingCartModel scm;
private ProductList pl;
    public ShoppingCartController(ShoppingCartView scv, ShoppingCartModel scm,ProductList pl) {
        this.scm = scm;
        this.scv = scv;
        this.pl = pl;
        setView();
        removeControl();
        orderControl();
    }
    public void removeControl()
    {
        scv.getTable().addMouseListener(new java.awt.event.MouseAdapter(){
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            int productID = Integer.parseInt(scv.getTable().getValueAt(scv.getTable().getSelectedRow(),0).toString());
            System.out.println(productID);
            Product p = pl.getProductFromID(productID);
            scm.getCartList().removeFromCart(p);
            scv.updateTable(scm.getTabledata(),scm.cl.getTotalCost());   
           
        }
        }
        );
    }
    public void orderControl()
    {
        scv.getOrderButton().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                if(scm.getCartList().isEmpty() == true)
                {
                    System.out.println("Your shopping cart is empty");
                    scv.errormessage("Cart is empty");
                }
                else
                {
                 OrderModel om = new OrderModel(scm.getCartList(),scm);
                 OrderView ov = new OrderView();
                 OrderController oc = new OrderController(om,ov);
                }
                 
            }
            
        });
    }
    public void setView()
    {
        scv.setView(scm.getTabledata(),scm.cl.getTotalCost());
    }
}
            
             