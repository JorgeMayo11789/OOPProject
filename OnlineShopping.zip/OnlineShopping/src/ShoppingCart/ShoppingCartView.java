/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ShoppingCart;
import java.awt.Container;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

/**
 *
 * @author jmayoral2017
 */
public class ShoppingCartView extends JFrame{
    JLabel l1, l2, l3;
    JButton btnOrder;
     public ShoppingCartView(CartList cl)
    {
        l1 = new JLabel("Shopping Cart");
    	 l2 = new JLabel("Total: $"+cl.getTotalCost());
    	 btnOrder = new JButton("Order");
        String[] columns = new String[] {
            "Id", "Name", "Cost", "Quantity"
        };
        Object[][] data = new Object[cl.size()][4];
        //actual data for the table in a 2d array
        ////////
        JTable table = new JTable(data, columns);
        for(int i = 0;i<cl.size();i++)
         {
             data[i][0] = cl.p.get(i).getID();
             System.out.println(cl.p.get(i).getName());
             data[i][1] = cl.p.get(i).getName();
             data[i][2] = cl.p.get(i).getCost();
             data[i][3] = cl.quantity.get(i);
         }
        //table.setBounds(20, 20, 20, 20);
        table.setPreferredScrollableViewportSize(table.getPreferredSize());
        table.setFillsViewportHeight(true);
        table.setDefaultEditor(Object.class, null);
        Container c = getContentPane(); 
        c.setLayout(null); 
        JScrollPane scroller = new JScrollPane(table); 
        scroller.setBounds(10, 100,400, 200);
        c.add(scroller); 
        c.add(l1);
        c.add(l2);
        c.add(btnOrder);
        l1.setBounds(165, 50, 100, 50);
        l2.setBounds(100, 500, 100, 50);
        btnOrder.setBounds(340, 500, 70, 50);
        this.setLayout(null);
        this.setTitle("Table Example");
        //this.pack();
        this.setSize(435,600);
        this.setLocationRelativeTo(null); 
        this.setVisible(true);
    }
    
}
