/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ShoppingCart;

import ProductList.Product;
import java.util.ArrayList;

/**
 *
 * @author jmayoral2017
 */
public class CartList {
    ArrayList<Product> p = new ArrayList<Product>();
    ArrayList<Integer> quantity = new ArrayList<Integer>();
    public CartList()
    {
        
    }
    public int size()
    {
        return p.size();
    }
    public double getTotalCost()
    {
        double total = 0;
        for(int i = 0;i<p.size();i++)
        {
            total = total+p.get(i).getCost()*quantity.get(i);
        }
        return total;
    }
    public void addToCart(Product p1)
    {
        int repeat = 0;
        if(p.size() == 0)
        {
            p.add(p1);
            quantity.add(1);
        }
        else
        {
            for(int i = 0;i<p.size();i++)
        {
            if(p.get(i).getID() == p1.getID())
            {
                quantity.set(i,quantity.get(i)+1);
                repeat = 1;
            }
        }
        if(repeat == 0)
        {
            p.add(p1);
            quantity.add(1);
        }
        }
        
    }
}
