/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ShoppingCart;

import ProductList.Product;
import ProductList.ProductList;
import java.io.IOException;
import java.util.ArrayList;
public class CartList {
    ProductList pl;
    ArrayList<Product> p = new ArrayList<Product>();
    ArrayList<Integer> quantity = new ArrayList<Integer>();
    public CartList()
    {
        
    }
    public int getProductQuantity(Product p1)
    {
        if(p.contains(p1))
        {
            int index = p.indexOf(p1);
            System.out.println(p.indexOf(p1));
            return quantity.get(index); 
        }
        else
        {
            return 0;
        }
    }
    public boolean isEmpty()
    {
        return p.isEmpty();
    }
    public int size()
    {
        return p.size();
    }
    public double getTotalCost()
    {
        double total = 0;
        for(int i = 0;i<p.size();i++)
        {
            total = total+p.get(i).getCost()*quantity.get(i);
        }
        return total;
    }
    public void addToCart(Product p1)
    {
        if(p.contains(p1))
        {
            int index = p.indexOf(p1);
            if(quantity.get(index) >= p1.getquantity())
            {
                System.out.println("no more quantity");
            }
            else
            {
                int repeat = 0;
        if(p.size() == 0)
        {
            p.add(p1);
            quantity.add(1);
        }
        else
        {
            for(int i = 0;i<p.size();i++)
        {
            if(p.get(i).getID() == p1.getID())
            {
                quantity.set(i,quantity.get(i)+1);
                repeat = 1;
            }
        }
        if(repeat == 0)
        {
            p.add(p1);
            quantity.add(1);
        }
        }
            }
        }
        else
        {
            int repeat = 0;
        if(p.size() == 0)
        {
            p.add(p1);
            quantity.add(1);
        }
        else
        {
            for(int i = 0;i<p.size();i++)
        {
            if(p.get(i).getID() == p1.getID())
            {
                quantity.set(i,quantity.get(i)+1);
                repeat = 1;
            }
        }
        if(repeat == 0)
        {
            p.add(p1);
            quantity.add(1);
        }
        }
        
        }
        
    }
    public void removeFromCart(Product pone)
    {
        int index = p.indexOf(pone);
        {
            if(quantity.get(index) > 1)
            {
                quantity.set(index, quantity.get(index)-1);
            }
            else if(quantity.get(index) == 1)
            {
                quantity.remove(index);
                p.remove(pone);
            }
        }
    }

    public void updateQuantities() throws IOException {
        for(int i = 0;i<p.size();i++)
        {
           
            int amount = quantity.get(i);
            Product pone = p.get(i);
            pl.removeProduct(pone);
            pone.setquantity(pone.getquantity()-amount);
            pl.addProduct(pone);
            pl.updateProductFile();
        }
    }
    public void addList(ProductList pl) {
        this.pl = pl;
    }
}
