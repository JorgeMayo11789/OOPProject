/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ShoppingCart;

import ProductList.ProductListController;
import ProductList.ProductListView;
import javax.swing.JTable;

public class ShoppingCartModel {
    ProductListView v;
    CartList cl = null;
    public ShoppingCartModel(ProductListView v,CartList cl)
    {
        this.v = v;
        this.cl = cl;
    }
    public void updateProductListView()
    {
        v.updateTable();
    }
    public CartList getCartList()
    {
        return cl;
    }
    public Object[][] getTabledata()
    {
         Object[][] data = new Object[cl.size()][4];
        //actual data for the table in a 2d array
        ////////
        for(int i = 0;i<cl.size();i++)
         {
             data[i][0] = cl.p.get(i).getID();
             System.out.println(cl.p.get(i).getName());
             data[i][1] = cl.p.get(i).getName();
             data[i][2] = cl.p.get(i).getCost();
             data[i][3] = cl.quantity.get(i);
         }
        return data;
    }
    
}
