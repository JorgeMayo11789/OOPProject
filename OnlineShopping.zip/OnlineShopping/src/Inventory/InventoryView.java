package Inventory;
import ProductList.ProductList;
import ProductList.Product;
import Users.CurrentUser;
import java.awt.BorderLayout;
import java.awt.Container;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
public class InventoryView extends JFrame
{
	JLabel l1, l2, l3;
	private JButton btnAddProduct, btnLogout;
        ProductList pl = new ProductList();
        private JTable table = null;
        CurrentUser u1 = null;
        private Container c = null;
        JScrollPane scroller = null; 
    public InventoryView(CurrentUser u1) throws FileNotFoundException
    {
        this.u1 = u1;
    	 l1 = new JLabel("Welcome");
    	 l2 = new JLabel("Product List");
    	 btnAddProduct = new JButton("Add New Product");
    	 btnLogout = new JButton("LogOut");
    	this.setLayout(new BorderLayout());
        //headers for the table
        String[] columns = new String[] {
            "Id", "Name", "Cost", "Stock","Seller"
        };
		 File file = new File("src/products.txt");
		 BufferedReader br = new BufferedReader(new FileReader(file)); 
		  String st;
		  String[] split;
		  try {
			while ((st = br.readLine()) != null)
			{
                            split = st.split("\\s+");
			    Product p1 = new Product(Integer.parseInt(split[0]),split[1],Double.parseDouble(split[2]),Integer.parseInt(split[3]),split[4]);
                            pl.addProduct(p1);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
                }
         Object[][] data = new Object[pl.size()][5];
         int j = 0;
         for(int i = 0;i<pl.size();i++)
         {
             
             if(pl.products.get(i).getSeller().equalsIgnoreCase(u1.user()))
             {
                 data[j][0] = pl.products.get(i).getID();
                 data[j][1] = pl.products.get(i).getName();
                 data[j][2] = pl.products.get(i).getCost();
                 data[j][3] = pl.products.get(i).getquantity();
                 data[j][4] = pl.products.get(i).getSeller();
                 j++;
             }
         }
        table = new JTable(data, columns);
        table.setDefaultEditor(Object.class, null);
        
        c = getContentPane(); 
        c.setLayout(null); 
        scroller = new JScrollPane(table); 
        c.add(scroller); 
        scroller.setBounds(160, 100, 700, 300);
        c.add(l1);
        c.add(btnLogout);
        c.add(btnAddProduct);
        l1.setBounds(450, 50, 100, 50);
        btnLogout.setBounds(880, 20, 100, 50);
        btnAddProduct.setBounds(700, 20, 150, 50);
        this.setLayout(null);
        this.setTitle("Table Example");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //this.pack();
        this.setSize(1000,500);
        this.setLocationRelativeTo(null); 
        this.setVisible(true);
    }
    public JTable getTable()
    {
        return table;
    }
    public JButton getCart()
    {
        return btnAddProduct;
    }

    ProductList getProductList() {
        return pl;
    }
    JButton getAddProductBtn()
    {
        return btnAddProduct;
    }

    JButton getLogout() {
        return btnLogout;
}
    public void updateTable(ProductList pl2) throws FileNotFoundException {
        c.remove(scroller);
        String[] columns = new String[] {
            "Id", "Name", "Cost", "Stock","Sellor"
        };
        Object[][] data = new Object[pl2.size()][5];
         int j = 0;
         for(int i = 0;i<pl2.size();i++)
         {
             if(pl.products.get(i).getSeller().equalsIgnoreCase(u1.user()))
             {
                 data[j][0] = pl2.products.get(i).getID();
                 data[j][1] = pl2.products.get(i).getName();
                 data[j][2] = pl2.products.get(i).getCost();
                 data[j][3] = pl2.products.get(i).getquantity();
                 data[j][4] = pl2.products.get(i).getSeller();
                 j++;
             }
             
         }
         DefaultTableModel dataModel = new DefaultTableModel(data, columns);
        table.setModel(dataModel);
        table.setDefaultEditor(Object.class, null);
        System.out.println("table repainted");
        scroller = new JScrollPane(table); 
        c.add(scroller);
        scroller.setBounds(160, 100, 700, 300);
        c.revalidate();
        c.repaint();
    }
}

