/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inventory;
import AddProduct.AddProductController;
import AddProduct.AddProductModel;
import AddProduct.AddProductView;
import EditProduct.*;
import ProductList.ProductList;
import ProductList.Product;
import Users.User;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InventoryController {
    private InventoryView iv;
    private InventoryModel im;
    private boolean closed = false;
    private ProductList pl;
    private User cu;
    public InventoryController(InventoryView iv, InventoryModel im,User cu)
    {
        this.iv = iv;
        this.im = im;
        this.cu = cu;
    }
    public void tableControl()
    {
       iv.getTable().addMouseListener(new java.awt.event.MouseAdapter(){
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            if(iv.getTable().getValueAt(iv.getTable().getSelectedRow(),0) == null)
            {
            }
            else
            {
            int productID = Integer.parseInt(iv.getTable().getValueAt(iv.getTable().getSelectedRow(),0).toString());
            pl = iv.getProductList();
            Product p = pl.getProductFromID(productID);
            EditProductView epv = new EditProductView(p);
            EditProductModel epm = new EditProductModel(p,pl);
            EditProductController epc = new EditProductController(epv,epm,iv,pl);
            epc.removeProductControl();
            epc.editProductControl();
            }
        }
    });
    }
    public void addNewProductButton()
    {
        iv.getAddProductBtn().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
               System.out.println("Adding Product");
               AddProductView apv = new AddProductView();
               AddProductModel apm = new AddProductModel();
                pl = iv.getProductList();
               AddProductController apc = new AddProductController(apv,apm,iv,pl,cu);
            }
        });
    }

    public boolean logoutControl() {
         iv.getLogout().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                iv.setVisible(false);
                iv.dispose();
                closed = true;
            }  
        });
        return closed;
    }
     public ProductList getProductList()
    {
        pl = iv.getProductList();
        return pl;
    }
}
