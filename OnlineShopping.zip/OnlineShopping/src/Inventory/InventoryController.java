/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inventory;
import AddProduct.AddProductController;
import AddProduct.AddProductModel;
import AddProduct.AddProductView;
import EditProduct.*;
import ProductList.ProductList;
import ProductList.Product;
import Users.User;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class InventoryController {
    private InventoryView iv;
    private InventoryModel im;
    private boolean closed = false;
    private ProductList pl;
    private User cu;
    public InventoryController(InventoryView iv, InventoryModel im,User cu) throws FileNotFoundException
    {
        this.iv = iv;
        this.im = im;
        this.cu = cu;
        setView();
    }
    public void tableControl()
    {
       iv.getTable().addMouseListener(new java.awt.event.MouseAdapter(){
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            if(iv.getTable().getValueAt(iv.getTable().getSelectedRow(),0) == null)
            {
            }
            else
            {
            int productID = Integer.parseInt(iv.getTable().getValueAt(iv.getTable().getSelectedRow(),0).toString());
                try {
                    pl = im.getProductList();
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(InventoryController.class.getName()).log(Level.SEVERE, null, ex);
                }
            Product p = pl.getProductFromID(productID);
            EditProductView epv = new EditProductView(p);
            EditProductModel epm = new EditProductModel(p,pl);
            EditProductController epc = new EditProductController(epv,epm,iv,pl);
            epc.removeProductControl();
            epc.editProductControl();
            }
        }
    });
    }
    public void addNewProductButton()
    {
        iv.getAddProductBtn().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
               System.out.println("Adding Product");
               AddProductView apv = new AddProductView();
               AddProductModel apm = new AddProductModel();
                try {
                    pl = im.getProductList();
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(InventoryController.class.getName()).log(Level.SEVERE, null, ex);
                }
               AddProductController apc = new AddProductController(apv,apm,iv,pl,cu);
            }
        });
    }

    public boolean logoutControl() {
         iv.getLogout().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                iv.setVisible(false);
                iv.dispose();
                closed = true;
            }  
        });
        return closed;
    }
     public ProductList getProductList()
    {
        pl = iv.getProductList();
        return pl;
    }
     public void setView() throws FileNotFoundException
     {
         iv.setTable(im.getTabledata());
         iv.setProductList(im.getProductList());
     }
}
