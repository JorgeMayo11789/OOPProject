/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inventory;

import AddProduct.AddProductController;
import AddProduct.AddProductModel;
import AddProduct.AddProductView;
import ProductList.ProductList;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class InventoryController {
    private InventoryView iv;
    private InventoryModel im;
    private ProductList pl;
    public InventoryController(InventoryView iv, InventoryModel im)
    {
        this.iv = iv;
        this.im = im;
    }
    public void addNewProductButton()
    {
        iv.getAddProductBtn().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
               System.out.println("Adding Product");
               AddProductView apv = new AddProductView();
               AddProductModel apm = new AddProductModel();
                pl = iv.getProductList();
               AddProductController apc = new AddProductController(apv,apm,pl);
            }
        });
    }
    public ProductList getProductList()
    {
        pl = iv.getProductList();
        return pl;
    }
}
