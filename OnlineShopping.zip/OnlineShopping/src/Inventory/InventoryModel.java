/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inventory;
import ProductList.Product;
import ProductList.ProductList;
import Users.User;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
public class InventoryModel {
    ProductList pl = new ProductList();
    User currentuser;
    public InventoryModel(User currentuser) throws FileNotFoundException
    {
        this.currentuser = currentuser;
        File file = new File("src/products.txt");
		 BufferedReader br = new BufferedReader(new FileReader(file)); 
		  String st;
		  String[] split;
		  try {
			while ((st = br.readLine()) != null)
			{
                            split = st.split("\\s+");
			    Product p1 = new Product(Integer.parseInt(split[0]),split[1],Double.parseDouble(split[2]),Integer.parseInt(split[3]),split[4]);
                            pl.addProduct(p1);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
                }
    }
    ProductList getProductList() throws FileNotFoundException 
    {
        
                  return pl;
    }
    public Object[][] getTabledata()
    {
        Object[][] data = new Object[pl.size()][5];
        int j = 0;
         for(int i = 0;i<pl.size();i++)
         {
             
             if(pl.products.get(i).getSeller().equalsIgnoreCase(currentuser.user()))
             {
                 data[j][0] = pl.products.get(i).getID();
                 data[j][1] = pl.products.get(i).getName();
                 data[j][2] = pl.products.get(i).getCost();
                 data[j][3] = pl.products.get(i).getquantity();
                 data[j][4] = pl.products.get(i).getSeller();
                 j++;
             }
         }
         return data;
    }
}

