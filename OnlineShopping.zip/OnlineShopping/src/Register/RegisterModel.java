/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Register;

import Users.UserList;

/**
 *
 * @author SupaManlyMan
 */
public class RegisterModel {
    public boolean checkUserList(String user, UserList l1) {
        int size = l1.getSize();
        for(int i =0;i<size;i++)
	{
		if(user.equals(l1.getUser(i)))
		{
			System.out.println("Username aready taken");
                        return false;
		}
	}
        return true;
    }
    
}
